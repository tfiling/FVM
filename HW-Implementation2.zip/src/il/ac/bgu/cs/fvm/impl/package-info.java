/**
 * All student code lives inside this package, or in one of its sub-packages.
 * The testing framework takes this folder only, and places it in a fresh
 * codebase. So <em>everything outside of this package will not be available
 * at test time</em>. Don't depend on it.
 * 
 */
package il.ac.bgu.cs.fvm.impl;
